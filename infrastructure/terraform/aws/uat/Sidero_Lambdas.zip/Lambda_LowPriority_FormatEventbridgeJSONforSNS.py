import json
import boto3

sns = boto3.client('sns')

def lambda_handler(event, context):

    # Details from AWS Event
    description=event['detail']['alarmName']
    client = boto3.client('sns')
    response = client.publish (
      TargetArn = "arn:aws:sns:eu-west-1:100350071169:low_priority_alert",
      Message = json.dumps({'default': description}),
      MessageStructure = 'json'
    )

    return {
      'statusCode': 200,
      'body': json.dumps('Success!')
}